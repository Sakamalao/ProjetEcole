﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projet_v2
{
    public partial class Form1 : Form
    {
        Plateau Plat = new Plateau("Test1.csv");
        Dictionnaire FR = new Dictionnaire("Français");
        List<Joueur> J = new List<Joueur>();
        public Form1()
        {
            InitializeComponent();
        }        

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Affichage.ForeColor = Color.Black;
            Affichage.Font = new Font(FontFamily.GenericMonospace, 60);  /// Avoir une police et une taille de caractere prédéfinie
        }

        private void User_TextChanged(object sender, EventArgs e)
        {

        }

        private void Confirm_Word_Click(object sender, EventArgs e)
        {
            if (Enter_Word.Text == "") MessageBox.Show("Vous n'avez rien saisi");
            else
            {
                Plat.Maj_Plateau();
                Affichage.Text= Plat.toString();
                Affichage3.AppendText(Enter_Word.Text + ", ");
                Enter_Word.Text = "";
            }
        }
        
        private void Form1_Load(object sender, EventArgs e) ///Au démarage
        {
            LABEL1.Visible = false;
            Plat_Random.Visible = false;
            Plat_Random.Enabled = false;
            Plat_File.Visible = false;
            Plat_File.Enabled = false;
            Confirm_Word.Visible = false;
            Confirm_Word.Enabled = false;
            Enter_Word.Enabled = false;
            Enter_Word.Visible = false;
            Solo.Visible = false;
            Solo.Enabled = false;
            Duo.Visible = false;
            Duo.Enabled= false;
            Nom_Joueur.Enabled = false;
            Nom_Joueur.Visible = false;
            Game_Timer.Visible = false;
            Game_Timer.Enabled= false;
            Validate_Time.Visible = false;
            Validate_Time.Enabled = false;
            Affichage3.Enabled = false;
            Affichage3.Visible = false;
            this.Location = new Point(0, 0); ///Centrer l'affichage au milieu
            this.Size = new Size(1920,1080); ///Avoir une résoluion de 1920 par 1080 (valeur à changer selon votre ecran) 
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Info_Dictionnaire_Click(object sender, EventArgs e)
        {
            MessageBox.Show(FR.toString());
        }

        private void Starting_Click(object sender, EventArgs e)
        {
            Jeu Jeu = new Jeu();
            Jeu.copieFichier();
            Starting.Visible = false;
            Starting.Enabled = false;
            Plat_Random.Visible = true;
            Plat_Random.Enabled = true;
            Plat_File.Visible = true;
            Plat_File.Enabled = true;
            Affichage.Text = "Selectionnez la manière dont le tableau sera généré"; 
        }

        private void Plat_Random_Click(object sender, EventArgs e)
        {
            Plat_Random.Visible = false;
            Plat_Random.Enabled = false;
            Plat_File.Visible = false;
            Plat_File.Enabled = false;            
            Solo.Enabled = true;
            Solo.Visible = true;
            Duo.Enabled = true;
            Plat.plateauAléatoire();
            Duo.Visible = true;
            Nom_Joueur.Enabled = true;
            Nom_Joueur.Visible = true;
            Affichage.Text = "Combien de joueurs y aura t-il ? \r\nDonnez leurs noms (séparés par ','.)";
        }

        private void Plat_File_Click(object sender, EventArgs e)
        {
            Plat_Random.Visible = false;
            Plat_Random.Enabled = false;
            Plat_File.Visible = false;
            Plat_File.Enabled = false;
            Plat.toRead("Test1.csv");
            Solo.Enabled = true;
            Solo.Visible = true;
            Duo.Enabled = true;
            Duo.Visible = true;
            Nom_Joueur.Enabled = true;
            Nom_Joueur.Visible = true;
            Affichage.Text = "Combien de joueurs y aura t-il ? \r\nDonnez leurs noms (séparés par ','.)";
        }

        private void Nb_Joueur_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Validate_Nb_Joueur_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] s = Nom_Joueur.Text.Split(',');
            if (s.Length != 1 || Nom_Joueur.Text == "")
            {
                MessageBox.Show("Il y a un problème de saisie");
            }
            else
            {
                for (int i = 0; i < 1; i++)
                {
                    J.Add(new Joueur(s[i]));
                    MessageBox.Show(J[i].toString());
                    Affichage2.AppendText(J[i].toString());
                }
                Nom_Joueur.Clear();
                Nom_Joueur.Enabled = false;
                Nom_Joueur.Visible = false;
                Solo.Enabled = false;
                Solo.Visible = false;
                Duo.Enabled = false;
                Duo.Visible = false;
                Affichage.Text = "Combien de temps durera la partie";
                Game_Timer.Visible = true;
                Game_Timer.Enabled = true;
                Validate_Time.Visible = true;
                Validate_Time.Enabled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] s = Nom_Joueur.Text.Split(',');
            if (s.Length != 2 || Nom_Joueur.Text=="")
            {
                MessageBox.Show("Il y a un problème (nombre de joueur(s) différent du nombre de nom(s) saisi(s)");
            }
            else
            {
                for (int i = 0; i < 2; i++)
                {
                    J.Add(new Joueur(s[i]));
                    MessageBox.Show(J[i].toString());
                    if (i == 0) Affichage2.AppendText(J[i].toString() + "\r\n\r\n\r\n");
                    else Affichage2.AppendText(J[i].toString());
                }
                Nom_Joueur.Clear();
                Nom_Joueur.Enabled = false;
                Nom_Joueur.Visible = false;
                Solo.Enabled = false;
                Solo.Visible = false;
                Duo.Enabled = false;
                Duo.Visible = false;
                Affichage.Text = "Combien de temps durera la partie";
                Game_Timer.Visible = true;
                Game_Timer.Enabled = true;
                Validate_Time.Visible = true;
                Validate_Time.Enabled = true;
            }
        }

        private void Nom_Joueur_TextChanged(object sender, EventArgs e)
        {

        }

        private void Validate_Time_Click(object sender, EventArgs e)
        {
            if (Game_Timer.Value == 0)
            {
                MessageBox.Show("Entrée non valide.");
            }
            else
            {
                int t = Convert.ToInt32(Game_Timer.Value);
                Game_Timer.Visible = false;
                Game_Timer.Enabled = false;
                Validate_Time.Visible = false;
                Validate_Time.Enabled = false;
                Affichage.Text = Plat.toString();
                Confirm_Word.Visible = true;
                Confirm_Word.Enabled = true;
                Enter_Word.Enabled = true;
                Enter_Word.Visible = true;
                LABEL1.Visible = true;
                Affichage3.Enabled = true;
                Affichage3.Visible = true;
            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            
        }

    }
}
