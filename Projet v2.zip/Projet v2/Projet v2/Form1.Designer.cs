﻿namespace Projet_v2
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.Affichage = new System.Windows.Forms.TextBox();
            this.Enter_Word = new System.Windows.Forms.TextBox();
            this.Confirm_Word = new System.Windows.Forms.Button();
            this.LABEL1 = new System.Windows.Forms.Label();
            this.Info_Dictionnaire = new System.Windows.Forms.Button();
            this.Starting = new System.Windows.Forms.Button();
            this.Plat_Random = new System.Windows.Forms.Button();
            this.Plat_File = new System.Windows.Forms.Button();
            this.Nom_Joueur = new System.Windows.Forms.TextBox();
            this.Solo = new System.Windows.Forms.Button();
            this.Duo = new System.Windows.Forms.Button();
            this.Game_Timer = new System.Windows.Forms.NumericUpDown();
            this.Validate_Time = new System.Windows.Forms.Button();
            this.Affichage2 = new System.Windows.Forms.TextBox();
            this.Affichage3 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Game_Timer)).BeginInit();
            this.SuspendLayout();
            // 
            // Affichage
            // 
            this.Affichage.BackColor = System.Drawing.SystemColors.Info;
            this.Affichage.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Affichage.Cursor = System.Windows.Forms.Cursors.No;
            this.Affichage.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Affichage.Location = new System.Drawing.Point(12, 12);
            this.Affichage.Multiline = true;
            this.Affichage.Name = "Affichage";
            this.Affichage.ReadOnly = true;
            this.Affichage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Affichage.Size = new System.Drawing.Size(1318, 1024);
            this.Affichage.TabIndex = 0;
            this.Affichage.Text = "Bienvenue au jeu des mots !";
            this.Affichage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Affichage.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Enter_Word
            // 
            this.Enter_Word.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Enter_Word.Location = new System.Drawing.Point(1429, 791);
            this.Enter_Word.Name = "Enter_Word";
            this.Enter_Word.Size = new System.Drawing.Size(412, 26);
            this.Enter_Word.TabIndex = 1;
            this.Enter_Word.TextChanged += new System.EventHandler(this.User_TextChanged);
            // 
            // Confirm_Word
            // 
            this.Confirm_Word.Location = new System.Drawing.Point(1608, 841);
            this.Confirm_Word.Name = "Confirm_Word";
            this.Confirm_Word.Size = new System.Drawing.Size(73, 34);
            this.Confirm_Word.TabIndex = 2;
            this.Confirm_Word.Text = "Valider";
            this.Confirm_Word.UseVisualStyleBackColor = true;
            this.Confirm_Word.Click += new System.EventHandler(this.Confirm_Word_Click);
            // 
            // LABEL1
            // 
            this.LABEL1.AutoSize = true;
            this.LABEL1.Location = new System.Drawing.Point(1555, 747);
            this.LABEL1.Name = "LABEL1";
            this.LABEL1.Size = new System.Drawing.Size(172, 20);
            this.LABEL1.TabIndex = 3;
            this.LABEL1.Text = "Saisissez votre mot ici :";
            this.LABEL1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Info_Dictionnaire
            // 
            this.Info_Dictionnaire.Location = new System.Drawing.Point(1762, 976);
            this.Info_Dictionnaire.Name = "Info_Dictionnaire";
            this.Info_Dictionnaire.Size = new System.Drawing.Size(124, 36);
            this.Info_Dictionnaire.TabIndex = 4;
            this.Info_Dictionnaire.Text = "Information ⓘ";
            this.Info_Dictionnaire.UseVisualStyleBackColor = true;
            this.Info_Dictionnaire.Click += new System.EventHandler(this.Info_Dictionnaire_Click);
            // 
            // Starting
            // 
            this.Starting.Location = new System.Drawing.Point(1559, 669);
            this.Starting.Name = "Starting";
            this.Starting.Size = new System.Drawing.Size(166, 63);
            this.Starting.TabIndex = 5;
            this.Starting.Text = "Commencer";
            this.Starting.UseVisualStyleBackColor = true;
            this.Starting.Click += new System.EventHandler(this.Starting_Click);
            // 
            // Plat_Random
            // 
            this.Plat_Random.Location = new System.Drawing.Point(1453, 528);
            this.Plat_Random.Name = "Plat_Random";
            this.Plat_Random.Size = new System.Drawing.Size(146, 43);
            this.Plat_Random.TabIndex = 6;
            this.Plat_Random.Text = "Aléatoire";
            this.Plat_Random.UseVisualStyleBackColor = true;
            this.Plat_Random.Click += new System.EventHandler(this.Plat_Random_Click);
            // 
            // Plat_File
            // 
            this.Plat_File.Location = new System.Drawing.Point(1685, 527);
            this.Plat_File.Name = "Plat_File";
            this.Plat_File.Size = new System.Drawing.Size(156, 44);
            this.Plat_File.TabIndex = 7;
            this.Plat_File.Text = "A partir d\'un fichier";
            this.Plat_File.UseVisualStyleBackColor = true;
            this.Plat_File.Click += new System.EventHandler(this.Plat_File_Click);
            // 
            // Nom_Joueur
            // 
            this.Nom_Joueur.Location = new System.Drawing.Point(1495, 471);
            this.Nom_Joueur.Name = "Nom_Joueur";
            this.Nom_Joueur.Size = new System.Drawing.Size(303, 26);
            this.Nom_Joueur.TabIndex = 10;
            this.Nom_Joueur.TextChanged += new System.EventHandler(this.Nom_Joueur_TextChanged);
            // 
            // Solo
            // 
            this.Solo.Location = new System.Drawing.Point(1516, 609);
            this.Solo.Name = "Solo";
            this.Solo.Size = new System.Drawing.Size(83, 33);
            this.Solo.TabIndex = 11;
            this.Solo.Text = "Solo";
            this.Solo.UseVisualStyleBackColor = true;
            this.Solo.Click += new System.EventHandler(this.button1_Click);
            // 
            // Duo
            // 
            this.Duo.Location = new System.Drawing.Point(1685, 608);
            this.Duo.Name = "Duo";
            this.Duo.Size = new System.Drawing.Size(90, 34);
            this.Duo.TabIndex = 12;
            this.Duo.Text = "Duo";
            this.Duo.UseVisualStyleBackColor = true;
            this.Duo.Click += new System.EventHandler(this.button2_Click);
            // 
            // Game_Timer
            // 
            this.Game_Timer.Location = new System.Drawing.Point(1608, 361);
            this.Game_Timer.Name = "Game_Timer";
            this.Game_Timer.Size = new System.Drawing.Size(120, 26);
            this.Game_Timer.TabIndex = 13;
            // 
            // Validate_Time
            // 
            this.Validate_Time.Location = new System.Drawing.Point(1606, 416);
            this.Validate_Time.Name = "Validate_Time";
            this.Validate_Time.Size = new System.Drawing.Size(94, 49);
            this.Validate_Time.TabIndex = 14;
            this.Validate_Time.Text = "Valider";
            this.Validate_Time.UseVisualStyleBackColor = true;
            this.Validate_Time.Click += new System.EventHandler(this.Validate_Time_Click);
            // 
            // Affichage2
            // 
            this.Affichage2.Cursor = System.Windows.Forms.Cursors.No;
            this.Affichage2.Location = new System.Drawing.Point(1382, 12);
            this.Affichage2.Multiline = true;
            this.Affichage2.Name = "Affichage2";
            this.Affichage2.ReadOnly = true;
            this.Affichage2.Size = new System.Drawing.Size(492, 202);
            this.Affichage2.TabIndex = 15;
            this.Affichage2.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // Affichage3
            // 
            this.Affichage3.Cursor = System.Windows.Forms.Cursors.No;
            this.Affichage3.Location = new System.Drawing.Point(1382, 220);
            this.Affichage3.Multiline = true;
            this.Affichage3.Name = "Affichage3";
            this.Affichage3.ReadOnly = true;
            this.Affichage3.Size = new System.Drawing.Size(492, 202);
            this.Affichage3.TabIndex = 16;
            this.Affichage3.Text = "Mots trouvés: ";
            // 
            // Form1
            // 
            this.AcceptButton = this.Confirm_Word;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1898, 1024);
            this.Controls.Add(this.Affichage3);
            this.Controls.Add(this.Affichage2);
            this.Controls.Add(this.Validate_Time);
            this.Controls.Add(this.Game_Timer);
            this.Controls.Add(this.Duo);
            this.Controls.Add(this.Solo);
            this.Controls.Add(this.Nom_Joueur);
            this.Controls.Add(this.Plat_File);
            this.Controls.Add(this.Plat_Random);
            this.Controls.Add(this.Starting);
            this.Controls.Add(this.Info_Dictionnaire);
            this.Controls.Add(this.LABEL1);
            this.Controls.Add(this.Confirm_Word);
            this.Controls.Add(this.Enter_Word);
            this.Controls.Add(this.Affichage);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Game_Timer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Affichage;
        private System.Windows.Forms.TextBox Enter_Word;
        private System.Windows.Forms.Button Confirm_Word;
        private System.Windows.Forms.Label LABEL1;
        private System.Windows.Forms.Button Info_Dictionnaire;
        private System.Windows.Forms.Button Starting;
        private System.Windows.Forms.Button Plat_Random;
        private System.Windows.Forms.Button Plat_File;
        private System.Windows.Forms.TextBox Nom_Joueur;
        private System.Windows.Forms.Button Solo;
        private System.Windows.Forms.Button Duo;
        private System.Windows.Forms.NumericUpDown Game_Timer;
        private System.Windows.Forms.Button Validate_Time;
        private System.Windows.Forms.TextBox Affichage2;
        private System.Windows.Forms.TextBox Affichage3;
    }
}

